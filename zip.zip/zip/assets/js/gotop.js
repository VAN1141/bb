(function($){
    jQuery.fn.extend({
        // page top
        pageTop: function() {
            var $obj = $(this);
            var conf = {
                // vi tri cuon de bat dau hien thi tren cung
                viewScrollTop: 1
            }
            // ham main
            var main = function(){
                changeView();
                // cuon
                $(window).scroll(function() {
                    changeView();
                });
            }
            // chuyen doi hien thi tuy vao vi tri cuong
            var changeView = function() {
                if ($(window).scrollTop() > conf.viewScrollTop) {
                    $obj.show();
                } else {
                    $obj.hide();
                }
            }
            main();
        }
    });
    
})(jQuery);
$(document).ready(function() {
    // page top
    $('#page-top').pageTop();
    // scroll
    scroll();
});
/**
 * �X�N���[������
 */
function scroll() {
    // #xu ly nhap chuot vao
    $('a[href^=#top]').click(function() {
        // �X�N���[���̑��x
        var speed = 400;// �~���b
        // nhan gia tri lien ket mo neo
        var href= $(this).attr("href");
        // nhan dich den
        var target = $(href == "#" || href == "" ? 'html' : href);
        // so diem den
        var position = target.offset().top;
        // cuon muot
        $('body,html').animate({scrollTop:position}, speed, 'swing');
        return false;
    });
}