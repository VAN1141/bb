function updatePost() {
    var $contentID = null;
    var $sectionName = $('#sectionName').val();
    var $DOMID = $('#sectionID').val();
    var $sectionContent = tinyMCE.get('sectionContent').getContent();
    var urlParams = new URLSearchParams(window.location.search);
    var $IDPost = urlParams.get('ID');
    var $hasrelated = false;
    if ($(".selectPost").filter(function() { return $(this).val(); }).length > 0) {
        var $hasrelated = true
      };
    $.ajax({ //Post noi dung van ban len db
        type: "POST",
        url: "./api/updatePost.asp",
        data: {
            'IDPost': $IDPost,
            'DOMID': "'" + $DOMID + "'",
            'sectionContent': "'" + $sectionContent + "'",
            'sectionName': "'" + $sectionName + "'",
            'Related': $hasrelated
        },
        success: function (res, _, xhr) { //sau khi dua noi dung len db lay ID cua muc do
            $contentID = xhr.getResponseHeader("contentID")
            alert($contentID)
            console.log(res)
        }
    }).done(function () { // Tao van ban lien quan voi ID cua muc vua tao
        $('.relatedinfo').each(function(index, value){
            var $relatedid = $(this).find('.relatedid').val();
            var $IDPostLinkedTo = $(this).find('.postid').val();
            var $DOMLinkedTo = $(this).find('.writeID').val();
            var $DisplayText = $(this).find('.displaytext').val();
            if($relatedid){ //Neu tren db da co muc lien quan thi update
                $.post({
                    type: "POST",
                    url: "./api/updateRelatedPost.asp",
                    data: {
                        'relatedID': $relatedid,
                        'DisplayText': "'Title'",
                        'IDPostLinkedTo': $idpostrelatedto,
                        'DOMLinkedTo': "'" + $DOM + "'",
              'IDContent': $contentID
                    },
                    success: function(res,_,xhr){
                        console.log(res)
                    }
        
                })
            } else { // Neu khong thi tao moi
                 $.post({
                    type: "POST",
                    url: "./api/createRelatedPost.asp",
                    data: {
                        'IDContent': $contentID,
                        'DisplayText': "'" + $DisplayText + "'",
                        'IDPostLinkedTo': $IDPostLinkedTo,
                        'DOMLinkedTo': "'" + $DOMLinkedTo + "'",
                    },
                    success: function(res,_,xhr){
                        console.log(res)
                    }
        
                })
            };
            if($deletequeuerelated.length > 0){
                //Khong lam gi
            }
        })
    })
}

var $deletequeuerelated = [];
function addtodeletequeuerelated(obj, ID){
    $this = $(obj)
    $deletequeuerelated.push(ID);
    $this.parents().eq(1).remove();
}
function deleterelated(obj){
    $this = $(obj)
    $this.parents().eq(1).remove();
}