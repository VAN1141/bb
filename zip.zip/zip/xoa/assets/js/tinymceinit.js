//Tinymce config
$('textarea#sectionContent').tinymce({
    plugins: "anchor code paste table link lists ",
    menubar: false,
    toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | anchor | code | link | table tabledelete | tableprops tablerowprops tablecellprops | tableinsertrowbefore tableinsertrowafter tabledeleterow | tableinsertcolbefore tableinsertcolafter tabledeletecol",
    paste_word_valid_elements: "-strong/b,-em/i,-span,-p,-h1,-h2,-h3,-h4,-h5,-h6,-table[border|cellspacing|cellpadding|frame|rules|align|summary|style|class],-tr[rowspan|align|valign|style],tbody,thead,tfoot,#td[colspan|rowspan|align|valign|scope|style],#th[colspan|rowspan|align|valign|scope|style],-a[href|title],img[src|title|alt|class],sub,sup,strike,caption,br",
    paste_retain_style_properties: "color font-size border border-top border-left border-bottom border-right border-color width height background background-color margin margin-left margin-right padding padding-top padding-left padding-bottom padding-right text-align align",
    paste_convert_word_fake_lists: false,
    setup: editor => {
        // Apply the focus effect
        editor.on("init", () => {
            editor.getContainer().style.transition =
                "border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out";
        });
        editor.on("focus", () => {
            (editor.getContainer().style.boxShadow =
                "0 0 0 .2rem rgba(0, 123, 255, .25)"),
            (editor.getContainer().style.borderColor = "#80bdff");
        });
        editor.on("blur", () => {
            (editor.getContainer().style.boxShadow = ""),
            (editor.getContainer().style.borderColor = "");
        });
    },
    formats: {
        borderstyle: {
            selector: 'td,th',
            styles: {
                borderTopStyle: 'solid',
                borderRightStyle: 'solid',
                borderBottomStyle: 'solid',
                borderLeftStyle: 'solid',
            },
            remove_similar: true
        },
        bordercolor: {
            selector: 'td,th',
            styles: {
                borderTopColor: '#32CD32',
                borderRightColor: '#32CD32',
                borderBottomColor: '#32CD32',
                borderLeftColor: '#32CD32'
            },
            remove_similar: true
        },
        backgroundcolor: {
            selector: 'td,th',
            styles: {
                backgroundColor: '#006400'
            },
            remove_similar: true
        },
        formatpainter_removeformat: [{
                selector: 'b,strong,em,i,font,u,strike,sub,sup,dfn,code,samp,kbd,var,cite,mark,q,del,ins',
                remove: 'all',
                split: true,
                expand: false,
                block_expand: true,
                deep: true
            },
            {
                selector: 'span',
                attributes: ['style', 'class'],
                remove: 'empty',
                split: true,
                expand: false,
                deep: true
            },
            {
                selector: '*:not(tr,td,th,table)',
                attributes: ['style', 'class'],
                split: false,
                expand: false,
                deep: true
            }
        ]
    },
});


// Prevent Bootstrap dialog from blocking focusin
$(document).on('focusin', function (e) {
    if ($(e.target).closest(".tox-tinymce-aux, .moxman-window, .tam-assetmanager-root").length) {
        e.stopImmediatePropagation();
    }
});

