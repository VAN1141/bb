var deletequeuerevised = [];
var deletequeuerelated = [];
var deletequeueguiding = [];


$(document).ready(function () {
    //Lay du lieu cua caterogy va them vao lua chon 'Nhap van ban'
    $.ajax({
        type: "GET",
        url: "../../api/read/PostList.asp",
        success: function (res, _, xhr) {
            if (xhr.getResponseHeader('code') === '1') {
                $('#listpost').html(res);
                console.log('Lay danh sach bai viet thanh cong');
            } else {
                alert(xhr.getResponseHeader('code'))
            }
        }
    });
})

function getID(obj) { //Lay danh sach DOMID cua van ban duoc chon
    var $this = $(obj);
    var text = $this.val();
    var parent = $this.parent();
    var option = $('#listpost').find("option[value='" + text + "']");
    var bigparent = $this.parents().eq(2);
    var IDInput = bigparent.find('.writeID');
    var IDList = bigparent.find('datalist[id^="listDOMID"]');
    var postID = option.text();
    var hiddenpostid = parent.find('.postid');
    hiddenpostid.val(postID);
    if (postID) {
        $.ajax({
            type: "GET",
            url: "../../api/read/IDList.asp",
            data: {
                'IDBaiViet': postID
            },
            success: function (res, _, xhr) {
                IDList.html(res);
                IDInput.val("");
                console.log("Thanh cong")
            },
        })
    } else {
        IDInput.val("");
        IDList.html("");
    }
}

function appendtemplate(id) { //Them van ban lien quan
    $("#formRelated").tmpl({
        'number': Date.now()
    }).appendTo(id);
}

function addtodeletequeuerelated(obj, ID){ //Xoa van ban lien quan da co tren db
    $this = $(obj)
    $deletequeuerelated.push(ID);
    $this.parents().eq(1).remove();
    console.log($deletequeuerelated);
}
function deleterelated(obj){ //Xoa van ban lien quan da dc them bang nut an
    $this = $(obj)
    $this.parents().eq(1).remove();
}

function updatePost() { //Luu post
    var sectionName = $('#sectionName').val();
    var DOMID = $('#sectionID').val();
    var sectionContent = tinyMCE.get('sectionContent').getContent();
    var urlParams = new URLSearchParams(window.location.search);
    var IDPost = urlParams.get('ID');
    var hasrelated = false;
    var hasguiding = false;
    var hasrevised = false;
    if ($("#relatedPost .selectPost").filter(function() { return $(this).val(); }).length > 0) {
        hasrelated = true
      };
      if ($("#guidingPost .selectPost").filter(function() { return $(this).val(); }).length > 0) {
        hasguiding = true
      };
      if ($("#revisedPost .selectPost").filter(function() { return $(this).val(); }).length > 0) {
        hasrevised = true
      };
    $.ajax({ //Post noi dung van ban len db
        type: "POST",
        url: "../../api/create/section.asp",
        data: {
            'IDPost': IDPost,
            'DOMID': `'${DOMID}'`,
            'sectionContent': `'${sectionContent}'`,
            'sectionName': `'${sectionName}'`,
            'hasRelatedPost': hasrelated,
            'hasGuidingPost': hasguiding,
            'hasRevisedPost': hasrevised
        },
        success: function (res, _, xhr) { //sau khi dua noi dung len db lay ID cua muc do
            var contentID = xhr.getResponseHeader("contentID")
            console.log(res)
            console.log(contentID)
        }
    }).done(function (res, _, xhr) { // Tao van ban lien quan voi ID cua muc vua tao
        var contentID = xhr.getResponseHeader("contentID")
        relatedpost(contentID);
        guidingpost(contentID);
        revisedpost(contentID);

    })
}

function relatedpost(contentID) {
    $('#relatedPost .info').each(function(index, value){ // Tao va cap nhat van ban lien quan
        var relatedid = $(this).find('.relatedid').val();
        var IDPostLinkedTo = $(this).find('.postid').val();
        var DOMLinkedTo = $(this).find('.writeID').val();
        var DisplayText = $(this).find('.displaytext').val();
        if(relatedid){ //Neu tren db da co muc lien quan thi update
            $.post({
                type: "POST",
                url: "../../api/update/relatedpost.asp",
                data: {
                    'relatedID': relatedid,
                    'DisplayText': `'${DisplayText}'`,
                    'IDPostLinkedTo': idpostrelatedto,
                    'DOMLinkedTo': `'${DOM}'`,
                    'IDContent': contentID
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        } else { // Neu khong thi tao moi
            $.post({
                type: "POST",
                url: "../../api/create/relatedpost.asp",
                data: {
                    'IDContent': contentID,
                    'DisplayText': `'${DisplayText}'`,
                    'IDPostLinkedTo': IDPostLinkedTo,
                    'DOMLinkedTo': `'${DOMLinkedTo}'`,
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        };
    });
    if(deletequeuerelated.length > 0){ // Xoa van ban lien quan
        deletequeuerelated.forEach(function(val){
            $.post({
                type: "POST",
                url: "../../api/delete/relatedpost.asp",
                data: {
                    'IDRelatedPost': val,
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        })
    };
}
function guidingpost(contentID) {
    $('#guidingPost .info').each(function(index, value){ // Tao va cap nhat van ban lien quan
        var guidingid = $(this).find('.guidingid').val();
        var IDPostLinkedTo = $(this).find('.postid').val();
        var DOMLinkedTo = $(this).find('.writeID').val();
        var DisplayText = $(this).find('.displaytext').val();
        if(guidingid){ //Neu tren db da co muc lien quan thi update
            $.post({
                type: "POST",
                url: "../../api/update/guidingpost.asp",
                data: {
                    'guidingID': guidingid,
                    'DisplayText': `'${DisplayText}'`,
                    'IDPostLinkedTo': IDPostLinkedTo,
                    'DOMLinkedTo': `'${DOM}'`,
                    'IDContent': contentID
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        } else { // Neu khong thi tao moi
            $.post({
                type: "POST",
                url: "../../api/create/guidingpost.asp",
                data: {
                    'IDContent': contentID,
                    'DisplayText': `'${DisplayText}'`,
                    'IDPostLinkedTo': IDPostLinkedTo,
                    'DOMLinkedTo': `'${DOMLinkedTo}'`,
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        };
    });
    if(deletequeueguiding.length > 0){ // Xoa van ban lien quan
        deletequeueguiding.forEach(function(val){
            $.post({
                type: "POST",
                url: "../../api/delete/guidingpost.asp",
                data: {
                    'IDGuidingPost': val,
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        })
    };
}
function revisedpost(contentID) {
    $('#revisedPost .info').each(function(index, value){ // Tao va cap nhat van ban lien quan
        var revisedid = $(this).find('.revisedid').val();
        var IDPostLinkedTo = $(this).find('.postid').val();
        var DOMLinkedTo = $(this).find('.writeID').val();
        var DisplayText = $(this).find('.displaytext').val();
        if(revisedid){ //Neu tren db da co muc lien quan thi update
            $.post({
                type: "POST",
                url: "../../api/update/revisedpost.asp",
                data: {
                    'revisedID':revisedid,
                    'DisplayText': `'${DisplayText}'`,
                    'IDPostLinkedTo': IDPostLinkedTo,
                    'DOMLinkedTo': `'${DOM}'`,
                    'IDContent': contentID
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        } else { // Neu khong thi tao moi
            $.post({
                type: "POST",
                url: "../../api/create/revisedpost.asp",
                data: {
                    'IDContent': contentID,
                    'DisplayText': `'${DisplayText}'`,
                    'IDPostLinkedTo': IDPostLinkedTo,
                    'DOMLinkedTo': `'${DOMLinkedTo}'`,
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        };
    });
    if(deletequeuerevised.length > 0){ // Xoa van ban lien quan
        deletequeuerevised.forEach(function(val){
            $.post({
                type: "POST",
                url: "../../api/delete/revisedpost.asp",
                data: {
                    'IDRevisedPost': val,
                },
                success: function(res,_,xhr){
                    console.log(res)
                }
    
            })
        })
    };
}
