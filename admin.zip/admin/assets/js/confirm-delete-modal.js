$('#confirmdeleteModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var ID = button.data('id')
    var Name = button.data('name')
    var modal = $(this)
    modal.find('.modal-body input').val(ID)
    modal.find('.modal-body .post-name').text(Name)
})